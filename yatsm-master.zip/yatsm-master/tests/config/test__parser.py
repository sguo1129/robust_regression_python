""" Tests for yatsm.config._parse.py
"""
import yatsm.config._parse as parse
