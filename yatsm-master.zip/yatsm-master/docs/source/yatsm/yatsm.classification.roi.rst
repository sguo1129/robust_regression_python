yatsm.classification.roi module
===============================

.. automodule:: yatsm.classification.roi
    :members:
    :undoc-members:
    :show-inheritance:
