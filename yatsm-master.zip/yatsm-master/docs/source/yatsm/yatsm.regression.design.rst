yatsm.regression.design module
==============================

.. automodule:: yatsm.regression.design
    :members:
    :undoc-members:
    :show-inheritance:
