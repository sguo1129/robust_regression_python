yatsm.mapping.changes module
============================

.. automodule:: yatsm.mapping.changes
    :members:
    :undoc-members:
    :show-inheritance:
