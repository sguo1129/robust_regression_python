yatsm.cli.pixel module
======================

.. automodule:: yatsm.cli.pixel
    :members:
    :undoc-members:
    :show-inheritance:
