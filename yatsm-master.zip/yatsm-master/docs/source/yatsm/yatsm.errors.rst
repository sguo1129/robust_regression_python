yatsm.errors module
===================

.. automodule:: yatsm.errors
    :members:
    :undoc-members:
    :show-inheritance:
