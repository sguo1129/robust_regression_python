yatsm.cli.batch module
======================

.. automodule:: yatsm.cli.batch
    :members:
    :undoc-members:
    :show-inheritance:
