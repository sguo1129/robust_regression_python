yatsm.cli.main module
=====================

.. automodule:: yatsm.cli.main
    :members:
    :undoc-members:
    :show-inheritance:
