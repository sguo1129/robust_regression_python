yatsm.cli.changemap module
==========================

.. automodule:: yatsm.cli.changemap
    :members:
    :undoc-members:
    :show-inheritance:
