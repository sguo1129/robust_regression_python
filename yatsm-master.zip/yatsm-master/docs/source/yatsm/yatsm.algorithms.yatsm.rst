yatsm.algorithms.yatsm module
=============================

.. automodule:: yatsm.algorithms.yatsm
    :members:
    :undoc-members:
    :show-inheritance:
