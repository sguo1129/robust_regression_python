yatsm.pipeline.tasks.classify module
====================================

.. automodule:: yatsm.pipeline.tasks.classify
    :members:
    :undoc-members:
    :show-inheritance:
