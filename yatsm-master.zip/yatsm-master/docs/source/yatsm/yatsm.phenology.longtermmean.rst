yatsm.phenology.longtermmean module
===================================

.. automodule:: yatsm.phenology.longtermmean
    :members:
    :undoc-members:
    :show-inheritance:
