yatsm.mapping.classification module
===================================

.. automodule:: yatsm.mapping.classification
    :members:
    :undoc-members:
    :show-inheritance:
