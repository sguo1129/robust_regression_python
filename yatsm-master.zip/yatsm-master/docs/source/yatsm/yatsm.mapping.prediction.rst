yatsm.mapping.prediction module
===============================

.. automodule:: yatsm.mapping.prediction
    :members:
    :undoc-members:
    :show-inheritance:
