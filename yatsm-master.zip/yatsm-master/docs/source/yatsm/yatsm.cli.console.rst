yatsm.cli.console module
========================

.. automodule:: yatsm.cli.console
    :members:
    :undoc-members:
    :show-inheritance:
