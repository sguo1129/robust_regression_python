yatsm.version module
====================

.. automodule:: yatsm.version
    :members:
    :undoc-members:
    :show-inheritance:
