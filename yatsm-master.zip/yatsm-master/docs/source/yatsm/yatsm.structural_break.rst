yatsm.structural_break package
==============================

Module contents
---------------

.. automodule:: yatsm.structural_break
    :members:
    :undoc-members:
    :show-inheritance:
