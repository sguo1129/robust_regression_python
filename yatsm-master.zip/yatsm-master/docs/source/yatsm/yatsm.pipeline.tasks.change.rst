yatsm.pipeline.tasks.change module
==================================

.. automodule:: yatsm.pipeline.tasks.change
    :members:
    :undoc-members:
    :show-inheritance:
