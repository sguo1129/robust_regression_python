yatsm.regression.packaged module
================================

.. automodule:: yatsm.regression.packaged
    :members:
    :undoc-members:
    :show-inheritance:
