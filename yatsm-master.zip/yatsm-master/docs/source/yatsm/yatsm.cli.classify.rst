yatsm.cli.classify module
=========================

.. automodule:: yatsm.cli.classify
    :members:
    :undoc-members:
    :show-inheritance:
