yatsm.cli.options module
========================

.. automodule:: yatsm.cli.options
    :members:
    :undoc-members:
    :show-inheritance:
