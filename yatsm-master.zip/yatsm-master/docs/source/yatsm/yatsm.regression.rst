yatsm.regression package
========================

Subpackages
-----------

.. toctree::

    yatsm.regression.pickles

Submodules
----------

.. toctree::

   yatsm.regression.cran
   yatsm.regression.design
   yatsm.regression.diagnostics
   yatsm.regression.packaged
   yatsm.regression.robust_fit
   yatsm.regression.transforms

Module contents
---------------

.. automodule:: yatsm.regression
    :members:
    :undoc-members:
    :show-inheritance:
