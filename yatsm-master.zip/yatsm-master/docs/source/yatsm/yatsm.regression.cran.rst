yatsm.regression.cran module
============================

.. automodule:: yatsm.regression.cran
    :members:
    :undoc-members:
    :show-inheritance:
