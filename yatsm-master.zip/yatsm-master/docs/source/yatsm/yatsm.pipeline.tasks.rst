yatsm.pipeline.tasks package
============================

Submodules
----------

.. toctree::

   yatsm.pipeline.tasks.change
   yatsm.pipeline.tasks.classify
   yatsm.pipeline.tasks.postprocess
   yatsm.pipeline.tasks.preprocess

Module contents
---------------

.. automodule:: yatsm.pipeline.tasks
    :members:
    :undoc-members:
    :show-inheritance:
