.. _yatsm_train:

`yatsm train`
----------------

Train classifier predicting land cover for each time segment within YATSM
output:

.. literalinclude:: usage/yatsm_train.txt
    :language: bash
