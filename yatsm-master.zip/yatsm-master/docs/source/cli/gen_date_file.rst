.. _gen_date_file:

`gen_date_file.sh`
------------------

Generate Date and Filename Lists:

.. literalinclude:: usage/gen_date_file.txt
    :language: bash
