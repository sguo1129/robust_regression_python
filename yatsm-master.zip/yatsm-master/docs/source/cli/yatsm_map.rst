.. _yatsm_map:

`yatsm map`
-----------

Create maps of coefficients, predicted images, or land cover for any given date
from YATSM output:

.. literalinclude:: usage/yatsm_map.txt
    :language: bash
