.. _yatsm_classify:

`yatsm classify`
-------------------

Classify all lines within an image using a trained classifier:

.. literalinclude:: usage/yatsm_classify.txt
