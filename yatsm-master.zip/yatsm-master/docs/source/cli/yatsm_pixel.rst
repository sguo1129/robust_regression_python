.. _yatsm_pixel:

`yatsm pixel`
--------------

Run YATSM for individual pixels with specified parameters:

.. literalinclude:: usage/yatsm_pixel.txt
    :language: bash
