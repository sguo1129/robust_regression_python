.. _yatsm_line:

`yatsm line`
---------------

Run YATSM in batch mode for entire lines:

.. literalinclude:: usage/yatsm_line.txt
    :language: bash
