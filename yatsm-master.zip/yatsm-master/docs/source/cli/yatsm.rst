.. _yatsm_cli:

`yatsm`
-------

YATSM Command Line Interface and Subcommands:

.. literalinclude:: usage/yatsm.txt
    :language: bash
