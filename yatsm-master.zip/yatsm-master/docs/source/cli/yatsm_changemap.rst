.. _yatsm_changemap:


`yatsm changemap`
--------------------

Create maps of change information from YATSM output:

.. literalinclude:: usage/yatsm_changemap.txt
    :language: bash
