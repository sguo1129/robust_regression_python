.. _guide_dataset_prep:

===================
Dataset Preparation
===================

This part of the guide is a work in progress. For now you can get an idea of how
the datasets should be organized and prepared by viewing two example datasets
located `here <https://github.com/ceholden/landsat_stack>`_.

The issue tracker on Github is being used to track additions to this
documentation section. Please see
`ticket 34 <https://github.com/ceholden/yatsm/issues/34>`_.
