.. _guide_models_ccdcesque:

CCDCesque
=========

A guide for the YATSM implementation of Continuous Classification and Change Detection (CCDC) :cite:`Zhu2014152`


.. graphviz:: ccdcesque.dot


.. bibliography:: ../../_static/index_refs.bib
   :style: plain
   :cited:
