.. _guide_classification:

==============
Classification
==============

The issue tracker on Github is being used to track additions to this
documentation section. Please see
`ticket 38 <https://github.com/ceholden/yatsm/issues/38>`_.
