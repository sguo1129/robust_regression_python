.. _guide_exploration:

===========================
Model Parameter Exploration
===========================

The issue tracker on Github is being used to track additions to this
documentation section. Please see
`ticket 35 <https://github.com/ceholden/yatsm/issues/35>`_.
