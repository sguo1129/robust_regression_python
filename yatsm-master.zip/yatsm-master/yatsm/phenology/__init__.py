""" Module for phenology related algorithms
"""
