""" Tasks for classifying time series segments

* ``classify``
"""
