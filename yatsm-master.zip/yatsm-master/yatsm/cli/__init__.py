""" YATSM command line interface based on click
"""
